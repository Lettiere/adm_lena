<?php include_once('views/partials/header.php'); ?>
<?php include_once('views/sections/cabecalho_secretaria_adm.php');?>
<?php include_once('views/partials/metricas.php');?>
<?php include_once('views/partials/footer.php'); ?>
<?php include_once('views/partials/footer_js.php'); ?>