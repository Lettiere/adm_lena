<div class="tab-pane fade " id="navs-justified-link-ativos" role="tabpanel">
            <ul class="timeline mb-0">
              <li class="timeline-item ps-4 border-left-dashed">
                <span
                  class="timeline-indicator-advanced timeline-indicator-success border-0 shadow-none">
                  <i class="bx bx-check-circle mt-1"></i>
                </span>
                <div class="timeline-event ps-0 pb-0">
                  <div class="timeline-header">
                    <small class="text-success text-uppercase fw-medium">sender</small>
                  </div>
                  <h6 class="mb-2">Veronica Herman</h6>
                  <p class="text-muted mb-0">101 Boulder, California(CA), 95959</p>
                </div>
              </li>
              <li class="timeline-item ps-4 border-transparent">
                <span
                  class="timeline-indicator-advanced timeline-indicator-primary border-0 shadow-none">
                  <i class="bx bx-map mt-1"></i>
                </span>
                <div class="timeline-event ps-0 pb-0">
                  <div class="timeline-header">
                    <small class="text-primary text-uppercase fw-medium">Receiver</small>
                  </div>
                  <h6 class="mb-2">Barry Schowalter</h6>
                  <p class="text-muted mb-0">939 Orange, California(CA), 92118</p>
                </div>
              </li>
            </ul>
            <div class="border-1 border-light border-top border-dashed mb-3 "></div>
            <ul class="timeline mb-0">
              <li class="timeline-item ps-4 border-left-dashed">
                <span
                  class="timeline-indicator-advanced timeline-indicator-success border-0 shadow-none">
                  <i class="bx bx-check-circle mt-1"></i>
                </span>
                <div class="timeline-event ps-0 pb-0">
                  <div class="timeline-header">
                    <small class="text-success text-uppercase fw-medium">sender</small>
                  </div>
                  <h6 class="mb-2">Myrtle Ullrich</h6>
                  <p class="text-muted mb-0">162 Windsor, California(CA), 95492 </p>
                </div>
              </li>
              <li class="timeline-item ps-4 border-transparent">
                <span
                  class="timeline-indicator-advanced timeline-indicator-primary border-0 shadow-none">
                  <i class="bx bx-map mt-1"></i>
                </span>
                <div class="timeline-event ps-0 pb-0">
                  <div class="timeline-header">
                    <small class="text-primary text-uppercase fw-medium">Receiver</small>
                  </div>
                  <h6 class="mb-2">Helen Jacobs</h6>
                  <p class="text-muted mb-0">487 Sunset, California(CA), 94043</p>
                </div>
              </li>
            </ul>
          </div>